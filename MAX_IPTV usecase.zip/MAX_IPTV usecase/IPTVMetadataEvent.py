#Importing reuired libraries
import datetime as dt
import json
import pyspark
from pyspark.sql import functions as f
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import HiveContext,SparkSession

#### Function to get max_createdmsec from Audit table ######

 def get_last_loadValue(audit_value, audit_schema, source_table, target_table):
    last_load_value = spark.sql("select coalesce(max(kafka_inserted_ts),'1969-01-01 00:59:59.999')  from imd_tdata_model.iptv_audit_table\
        where status= 'success' AND source_table ='stg_iptv_xvu_device_metadata' AND target_table='iptvmetadataevent' ")
    return last_load_value


#### Function to fetch data from source table with last_loaded_date > max_createdmsec  ######
def get_iptv_data(source_schema, last_loaded_date, max_createdmsec):
    df = spark.sql("select *  from stg_iptv.stg_iptv_xvu_device_metadata where kafka_inserted_ts >={0} "\
                   .format(last_loaded_date))
    return df



if __name__ == "__main__":



#Creating Spark Session 
    spark = SparkSession.builder\
        .master("yarn")\
        .enableHiveSupport()\
        .appName("CustomerFacingService_RouterSourceData")\
        .config("hive.exec.dynamic.partition", "true")\
        .config("hive.exec.dynamic.partition.mode", "nonstrict")\
        .config("spark.sql.warehouse.dir", "warehehousedir")\
        .getOrCreate()

    spark.conf.set("mapreduce.fileoutputcommitter.marksuccessfuljobs","false")

    exec_start_time = dt.datetime.utcnow().strftime("%Y-%m-%d %H:%m:%S")

    print("ETL Job execution started at " + str(exec_start_time))

    last_loaded_date = get_last_loadValue()

    print("Last loaded data is  = " + str(last_loaded_date))

  
    stg_iptv = get_iptv_data(last_loaded_date)
    
    iptv_data_cnt = stg_iptv.count()

    print("Incremental Data to be loaded to TDM Table =" + str(iptv_data_cnt) + " records")
    
if (iptv_data_cnt > 0):
    cpd=spark.sql("""select
    a.partyroleid as partyroleid,
    a.resourcenumber as resourcenumber
from
(
select  
    pr.id as partyroleid,
    cp.resourcenumber,
    row_number() over(partition by pr.id order by pr.id asc) as rn
from
    cdl_tdata_model.partyrole pr
inner join
    cdl_tdata_model.partydemographic pd
    on pr.id = pd.partyroleid
inner join
    cdl_tdata_model.partyproductinvolvementrole ppi
    on pr.id = ppi.partyroleid
inner join 
    (
    select
       cp.id,
       cp.productname,
       cp.productid,
       cp.marketsegment,
       cp.resourcenumber, --this is consumerexternalid or maxtv_account_id in HT CRM system
       cp.productstatus,
       cp.residentialpartyroleid
     from 
       cdl_tdata_model.customerproduct cp 
     where 
        cp.productcategory = 'FIX'
        and  cp.resourcenumber not like '0%'
        and cp.resourcenumber rlike '[0-9]'
        and cp.resourcenumber not rlike '[a-z]'
        and cp.resourcenumber not rlike '[A-Z]'
        and length(cp.resourcenumber) >= 8
        and upper(cp.productname) like '%MAXTV%' --348,460
    )cp
    on ppi.customerproductid = cp.id
where
    pr.type = 'FIX'
    and pd.categorylevel1 in ('PRI','Privatni')
    and current_date() between pr.validforbegin and pr.validforend
)a
where a.rn = 1""")

##This cpd source is for networkdevice table
 cpd_nd= spark.sql("""select
       cp.id,
       cp.productname,
       cp.productid,
       cp.marketsegment,
       cp.resourcenumber, --this is consumerexternalid or maxtv_account_id in HT CRM system
       cp.productstatus,
       cp.residentialpartyroleid
     from 
       cdl_tdata_model.customerproduct cp 
     where 
        cp.productcategory = 'FIX'
        and  cp.resourcenumber not like '0%'
        and cp.resourcenumber rlike '[0-9]'
        and cp.resourcenumber not rlike '[a-z]'
        and cp.resourcenumber not rlike '[A-Z]'
        and length(cp.resourcenumber) >= 8
        and upper(cp.productname) like '%MAXTV%'""")
        
        ##This transformation is for networkdevice table
        src_rec_nd = iptv.join(cpd_nd, on=[iptv.consumerexternalid == cpd.resourcenumber], how='left')
#print(src_rec_nd)
 ##This transformation is for networkdevice table
 src_nd=src_rec_nd.withColumn("LoadTimestamp", f.current_timestamp())\
                 .withColumn("type",f.lit("STB"))\
                 .withColumn("productclass",f.lit("NULL"))\
                 .withColumn("Description",f.lit("MAXTV set top box"))
 print(src_nd)
##This transformation is for networkdevice table
 nd=src_nd.select(col("nodeid").alias("id"),\
                   "eventid",\
                   "eventdate",\
                  "eventtime",\
                 "productclass",\
                    col("id").alias("CustomerProductID"),\
                    col("serial").alias("SerialNumber"),\
                    "type",\
                   col("clientversion").alias("SoftwareVersion"),\
                 col("nodemodel").alias("Model"),\
                    "Description")
#src.show(2)
##select(col("eventid").alias("id"),\
 nd.createOrReplaceGlobalTempView("nd")

 src_rec_nd = iptv.join(cpd, on=[iptv.consumerexternalid == cpd.resourcenumber], how='left')


##This transformation is for iptv metadata  table
 iptv = stg_iptv.withColumn('eventdate',regexp_replace(col("lastreportdtm"), "-", ""))\
    .withColumn("eventdate", f.substring("eventdate",0,8))\
    .withColumn("eventtime",f.to_timestamp("lastreportdtm","yyyy-MM-dd'T'HH:mm:ss'Z'").cast("timestamp"))\
    .withColumn("a",regexp_replace(col("eventtime"), ":",""))\
    .withColumn("b",regexp_replace(col("a"), "-",""))\
    .withColumn("c",regexp_replace(col("b"), " ",""))\
    .withColumn("eventid", f.concat('consumerexternalid','c'))


#ip=iptv.select("eventdate").show(2)

 print(iptv)
 src_rec_2_4 = iptv.join(df, on=[iptv.consumerexternalid == df.resourcenumber], how='left')
#print(src_rec_2_4)

 src_rec=src_rec_2_4.withColumn("LoadTimestamp", f.current_timestamp())
#print(src_rec)

##This transformation is for iptv metadata  table
 src=src_rec.select("eventid",\
                   "eventdate",\
                    "eventtime",\
                    "partyroleid",\
                    "consumerexternalid",\
                    "consumerid",\
                    "servicegroup",\
                    "Kafka_Inserted_Ts",\
                    "LoadTimestamp")
 src.show(2)

##print(src)
  ##This transformation is for iptv metadata  table
  src.createOrReplaceGlobalTempView("iptv")
  
   ##This transformation is for stbrole table
  stbrole=src_rec.withColumn("id",f.lit("NULL")).select("id","eventid",\
                   "eventdate",\
                    "eventtime",\
                       col("nodeid").alias("NetworkDeviceID"),\
                    "externalid",\
                    "macaddress",\
                    "primarycable",\
                    "oltslotport",\
                       "primaryidf",\
                       "ipaddress",\
                       col("gateway").alias("GatewayIPAddress"),\
                       "hdmi",\
                       col("neighbourhoodname").alias("ParentNodeName"),\
                       col("rebootdtm").alias("RebootDateTime"),\
                    "Kafka_Inserted_Ts",\
                    "LoadTimestamp")
 stbrole.show(2)
 stbrole.createOrReplaceGlobalTempView("stbrole")
 
  ##This transformation is for STBPerformance table
 STBPerformance=src_rec.withColumn("id",f.lit("NULL")).select("id","eventid",\
                   "eventdate",\
                    "eventtime",\
                       col("nodeid").alias("NetworkDeviceID"),\
                    "clockdrift",\
                    "freememory",\
                    "cpuusage",\
                    "Kafka_Inserted_Ts",\
                    "LoadTimestamp")
 STBPerformance.createOrReplaceGlobalTempView("STBPerformance")
   
   src_rec_count= stg_iptv.select('consumerexternalid').distinct().count()
   print("Total source count is : " + str(src_rec_count_df))

   tgt_rec_count_df= spark.sql("select distinct eventid from global_temp.iptv")
   tgt_rec_count = src_rec_count_df.count()
   print("Total target count is : " + str(tgt_rec_count))
   print("Total target count will be : " + str(tgt_rec_count))
     
    exec_end_time = dt.datetime.utcnow().strftime("%Y-%m-%d %H:%m:%S")
  
    print("ETL Job execution completed successfully at " + str(exec_end_time))

    if (src_rec_count == tgt_rec_count):
            source_stats = "Count of distinct event id =" + str(src_rec_count)
            target_stats = "Count of distinct event id =" + str(tgt_rec_count)
            ##This insert statement  is for iptv metadata  table
             insert_data_iptv = spark.sql("""Insert into imd_tdata_model.IPTVMetadataEvent \
                        PARTITION (eventdate)\
                        select eventid,\
                        eventtime,\
                        partyroleid,\
                        consumerexternalid,\
                        consumerid,\
                        servicegroup,\
                        Kafka_Inserted_Ts,\
                        LoadTimestamp,\
                        eventdate \
                        from global_temp.iptv""")
                        
                        insert_data_networkdevice = spark.sql("""Insert into imd_tdata_model.networkdevice1 \
                        PARTITION (eventdate,type)\
                        select id,\
                        eventtime,\
                        productclass as null,\
                        SerialNumber,\
                        CustomerProductID,\
                        eventid,\
                        SoftwareVersion,\
                        Model,\
                        Description,\
                        eventdate,\
                        type
                        from global_temp.nd""")
                        insert_data_stbrole = spark.sql("""Insert into imd_tdata_model.stbrole \
                        PARTITION (eventdate)\
                        select id,\
                        eventid,\
                        eventtime,\
                        NetworkDeviceID,\
                        externalid,\
                        macaddress,\
                        primarycable,\
                        oltslotport,\
                        primaryidf,\
                        ipaddress,\
                        GatewayIPAddress,\
                        hdmi,\
                        ParentNodeName,\
                        RebootDateTime,\
                        LoadTimestamp,\
                        eventdate
                        from global_temp.stbrole""")
                        insert_data_STBPerformance = spark.sql("""Insert into imd_tdata_model.STBPerformance \
                        PARTITION (eventdate)\
                        select id,\
                        eventid,\
                        eventtime,\
                        NetworkDeviceID,\
                        clockdrift,\
                        freememory,\
                        cpuusage,\
                        LoadTimestamp,\
                        eventdate
                        from global_temp.STBPerformance""")
            audit_column = 'Kafka_Inserted_Ts'
            audit_value = stg_iptv.select([max("Kafka_Inserted_Ts")]).collect()[0][0]
            audit_rec = (exec_start_time, exec_end_time, source_table, tdm_table, source_stats, target_stats, audit_column, audit_value, 'success')
            audit_rec_df = spark.createDataFrame([audit_rec],
                                                 ["execution_start", "execution_end", "source_table", "target_table",         "source_stats", "target_stats", "audit_column", "audit_value", "status"])
            audit_rec_df.write.insertInto(audit_schema, overwrite=False)
            print("ETL Job completed, Audit table updated successfully at " + str(exec_end_time))
            spark.stop()

    else:
            source_stats = "Count of distinct event id =" + str(src_cnt)
            target_stats = "Count of distinct event id =" + str(target_cnt)
            audit_column = 'createdmsec'
            audit_value = host_data.select([max("createdmsec")]).collect()[0][0]
            print("Record Count mistmatch between Source table and Target Table")
            print("Hence no data uploaded to TDM table")
            print("Clean Up Process Complete")
            audit_rec = (exec_start_time, exec_end_time, source_table, tdm_table, source_stats, target_stats, audit_column, audit_value, 'fail')
            audit_rec_df = spark.createDataFrame([audit_rec], ["execution_start", "execution_end", "source_table", "target_table", "source_stats"])
            audit_rec_df.write.insertInto(audit_schema, overwrite=False)
            spark.stop()
            
else:
        exec_end_time = dt.datetime.utcnow().strftime("%Y-%m-%d %H:%m:%S")
        src_cnt = 0
        target_cnt = 0
        source_stats = "Count of distinct event id =" + str(src_cnt)
        target_stats = "Count of distinct event id =" + str(target_cnt)
        audit_column = 'createdmsec'
        audit_value = max_createdmsec
        audit_rec = (exec_start_time, exec_end_time, source_table, tdm_table, source_stats, target_stats, audit_column, audit_value, 'success')
        audit_rec_df = spark.createDataFrame([audit_rec], ["execution_start", "execution_end", "source_table", "target_table", "source_stats"])
        audit_rec_df.write.insertInto(audit_schema, overwrite=False)
        print("No Data Avaialable Hence ETL Completed with 0 Records loaded to Target Table")
        spark.stop()


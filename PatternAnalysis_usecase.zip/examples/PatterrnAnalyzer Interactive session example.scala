// Command to run for interactive mode:
// spark2-shell --jars ./jar/patternAnalysis.jar

import bt.halo.utils.patternAnalysis.PatternAnalyzer


spark.version
spark.sparkContext.master

// this example data comes with PatternAnalyzer
val events_df = spark.sql("select * from ebr_test.event_table order by id")
events_df.show(false)

// events_df.write.mode("overwrite").format("orc").saveAsTable("ebr_test.event_table")


// Creating PatternAnalyzer instance
val pa = new PatternAnalyzer(spark.sqlContext, events_df, inputForm = "events", mode = "discovery", terminators = Array("Churn","Annex"), modeledLevel = "Churn")

// transforming events to paths
val transformed_df = pa.transform

transformed_df.count()
transformed_df.filter("terminating_event = 'Churn'").count()

transformed_df.show(200, truncate = false)

// write path table to Hive with ORC format
// transformed_df.write.mode("overwrite").format("orc").saveAsTable("ebr_test.path_table")

// PatternAnalyzer can also re-used already transformed paths during previous runs
val path_table = spark.sql("select * from ebr_test.path_table")
path_table.show(200, truncate = false)

val pa = new PatternAnalyzer(spark.sqlContext, path_table, inputForm = "paths", mode = "discovery", terminators = Array("Churn","Annex"), modeledLevel = "Churn")



// Having events transformed to paths, it is possible for PatternAnalyzer to use patternMatch method to find and analyze patterns.
// This is very convinient for validation of the business hypothesis. Patterns provided for patternMatch are just a regular expressions 
println("\npa.patternMatch demonstration:")
pa.patternMatch("(FFF).*(CCC|DDD)+").show(false)
pa.patternMatch("(FFF).*(CCC|DDD)+", targetLevel = "Churn").show(false)

// PatternAnalyzer can also evaluate the pattern to find how good it is at differentiating customers with different terminating events (churners vs non-churners)
// method evaluatePatternMatch can do this
pa.evaluatePatternMatch("(FFF).*(CCC|DDD)+", show = true)
pa.evaluatePatternMatch("((AAA).*){2}")


// What if we dont have hypothesis or the data is very noisy?
// We can use automated discovery based on PrefixSpan to find best patterns
val fpa = new pa.FrequentPatterns(minSupport = 0.1, maxPatternLength = 5)


// fpa.getFrequentPatterns method can show all found frequent patterns
println("fpa.getFrequentPatterns(\"all\"):")
fpa.getFrequentPatterns().show(60, truncate = false)
println("%d rows".format(fpa.getFrequentPatterns().count()))


// also patterns that are frequent only for churners' sub-population but not necessary for the rest of customers!
println("fpa.getFrequentPatterns(\"target\"):")
fpa.getFrequentPatterns("target").show(60, truncate = false)
println("%d rows".format(fpa.getFrequentPatterns("target").count()))


// PatternAnalyzer can automaticaly evaluate those patterns against defined terminators (here churn vs non-churn)
println("fpa.evaluatedFrequentPatterns:")
fpa.evaluatedFrequentPatterns.show(60, truncate = false)
println("%d rows".format(fpa.evaluatedFrequentPatterns.count()))


// and return only those patterns which are frequent for churners but not for others!
println("fpa.getOnlyTargetPatterns(minTargetFrequence = 2):")
val onlyTargetPatterns = fpa.onlyTargetPatterns
onlyTargetPatterns.show(60, truncate = false)
println("%d rows".format(onlyTargetPatterns.count()))


// Based on frequentPatterns and onlyTargetPatterns, PatternAnalyzer can create model (which is a collection of rules for scoring)
// Parameters are depicting confidenec and support 
println("Modelrules")
val modelRules = fpa.createModelRules(0.25, 0.01).orderBy($"confidence".desc)
modelRules.show(60, truncate = false)
println("%d rows".format(modelRules.count()))


// Scoring
//--------

// PatternAnalyzer can be also used for scoring new dataset
val new_event_df = events_df.filter("event not in ('Churn','Annex')")

val pas = new PatternAnalyzer(
    spark.sqlContext, inputDF = new_event_df, inputForm = "events", idColumn = "id", eventColumn = "event",
    timeColumn = "time", inputTargetShare=0.2
)

val to_score_df = pas.transform
to_score_df.select("id", "event_path", "length").show(200, false)


// There are 3 methods for scoring: full (all matched longest patterns are used and final score is averaged), fastHighest (longest pattern with highest confidence is used and rest are ignored), maxScore (only highest confidence pattern is matched regardles of the pattern length: not reccomended) 
println("Scored dataframe: mmethod \"full\"")
val scored_full = pas.score(spark.sparkContext, modelRules = modelRules, scoringMode = "full")
scored_full.select("id", "event_path", "length", "score", "expected_lift", "patterns", "patterns_matched", "pattern_lengths", "pattern_types").orderBy($"score".desc).show(60, truncate = false)

println("Scored dataframe: mmethod \"fastHighest\"")
val scored_max = pas.score(spark.sparkContext, modelRules = modelRules, scoringMode = "fastHighest")
scored_max.drop("event_path", "terminating_event", "terminator_time", "event_times").orderBy($"score".desc).show(60, truncate = false)

println("Scored dataframe: mmethod \"maxScore\"")
val scored_max = pas.score(spark.sparkContext, modelRules = modelRules, scoringMode = "maxScore")
scored_max.drop("event_path", "terminating_event", "terminator_time", "event_times").orderBy($"score".desc).show(60, truncate = false)



// Some other examples of patternMatch and evaluatePatternMatch

println("\npa.patternMatch(\"(CCC).*(DDD).*\").show(false)")
pa.patternMatch("(CCC).*(DDD).*").show(false)

println("\npa.patternMatch(\"((AAA).*){2}\").show(false)")
pa.patternMatch("((AAA).*){2}").show(false)

println("\npa.patternMatch(\"(AAA).*(CCC|DDD)+\", targetLevel = \"Churn\").show(false)")
pa.patternMatch("(AAA).*(CCC|DDD)+", targetLevel = "Churn").show(false)

println("\nevaluatePatternMatch(\"((AAA).*){2}\")")
pa.evaluatePatternMatch("((AAA).*){2}")

println("pa.evaluatePatternMatch(\"(FFF).*(CCC|DDD)+\", show = true, truncate = false)")
pa.evaluatePatternMatch("(FFF).*(CCC|DDD)+", show = true, truncate = false)

println("pa.evaluatePatternMatch(\"(AAA).*(BBB).*(AAA).*(DDD).*\", show = true, truncate = false)")
pa.evaluatePatternMatch("(AAA).*(BBB).*(AAA).*(DDD).*", show = true, truncate = false)


// clean up
fpa.freeCaches()
pa.freeCaches()
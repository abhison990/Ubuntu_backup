# PatternAnalyzer

Pattern Analyzer is a Halo tool for extracting, analyzing and building models based on sequences of events. It can be also used for scoring new datasets like any other estimator. It is the key algorithm used in *Event Based Retention* and similar cases.

Pattern Analyzer is given to Halo community as a part of Halo initiative.<br>
It is fully maintained by Halo team and can be used for free with Halo as long as Halo is being used by a given NatCo.


### Important versions and change log:

**v1.8.5**:
* Method getSessions added in the interactive mode (returns sessions consisting of events within a defined time frame)
* CLI and Jupyter API modified to use getSessions
* Frequent patterns and patternMatch() are available now in scoring mode (but still not evaluation methods as discovery mode is needed with defined terminators)
* Fixed a bug when PA in interactive session could sometimes re-use data that was cached by other instance of PA (very rare) 
* Demo and unit tests modified accordingly to cover new features
* Removed obligatory parameter inputTargetShare from scoring mode (now it is optional and left just for compatibility purposes with earlier codes)
* Simplified secondary constructor arguments for scoring mode (simplified syntax when still fully backward compatible with earlier versions)
* Simplified secondary constructor arguments for discovery mode (simplified syntax when still fully backward compatible with earlier versions)
* Information regarding frequent patterns is displayed again (bugfix)
* help screen now consists all new features added in v1.8.4 and v1.8.5


**v1.8.4**:
* Fixed a bug when PatternAnalyzer was matching not complete event names when shorter event name was also among identified patterns
* Now both behaviors are possible (overlapping and non-overlapping pattern names generated automatically) but enforcing event names' endings in patters is a default behavior
* Due to enforced event names' endings model rules created by version 1.8.4 and later (with default settings) are not compatible with earlier versions
* New exceptions created in order to better handling abnormal situations and better integration with testing utility
* Many other small improvements and fixes 


**v1.8.3**:
* Bugfix: Masked event names are used both for model building and for scoring (added in 1.8.0 but broken in 1.8.2)
* PatternAnalyzer can calculate frequent patterns also for non-discovery mode if needed
* Many new Unit Tests added: all methods and features as well as errors and exceptions are covered now and available via API


**v1.8.2**:
* New algorithm for finding sequences based on newer API is safe with multi-core yarn setup
* Unit tests are available from API level (yet testing dependences are needed to be present on tested environment)
* I have created framework to automate unit tests outside of dev tools
* Fixed Jupyter API to return patterns when scoring
* Fixed full scoring method when running from Jupyter API
* Many other improvements and optimizations like improved validation of user input parameters and more


**v1.8.0** and **1.8.1**:
* New pattern evaluation mechanics optimized for string and pattern matching (c.a. 400x faster than original SparkSQL / Hive mechanics)
* Improve handling of special characters (regex) in events' names
* Default scoring method changed to maxScore (earlier fastHighest)
* Demo objects are available in interactive mode (with Scala shell)


**v1.7.3**:
* maxScore method was added
* Default scoring method changed to fastHighest (earlier full)
* Several minor bugfixes and improvements


**v1.7.2**:
* Better session management
* Fixed bug which caused very small support / confidence level to create invalid names in Hive
* Default confidence threshold for model rules is set to 0.0 eliminating risk of starting pattern finding without values set for model creation later on
* Scoring with “full method”  returns also all longest patterns matched (as a list in an additional column) not only paths
* Demo adopted to test all new features
* Some other minor improvements and fixes


**v1.7.0** / **v1.7.1**:
* Jupyter integration and API for spark-submit command line for all main features
* More precise confidence and lift for TO patterns (inputTargetShare setting can override calculated share)
* Improved help screen with all current features described
* Constructor is not initializing spark session for not Spark based methods


**v1.6.0** / **v1.6.1**:
* Halo initial version based on developed BDC version
* targetOnlyPAtterns now are evaluated much faster
* createModelRules improved and much faster
* Better error / exception handling
* Jupyter integration and command line API for transform method
* Jupyter integration and command line API for finding frequent patterns in transformed paths
* Pattern analyzer can work with both events and pre-calculated paths
* Improvements and optimizations in findFrequentPAttern method


**v1.5.0**:
* BDC version ported and reimplemented for Spark 2.3.0 and Scala 2.11.8  
* Improved GC interactions and Clean-up


**v1.4.x**:
* Versions used with BDC for EBR in AL and GR for model deployment and operationalization
* Fully functional scoring method
* Optimizations for score method in Scala API (dictionary based scoring, broadcasted, fastscore added)
* Full feature Scala API for interactive mode
* Integration with Zeppelin
* Full error and exception handling


**v1.3.x**:
* Versions used with BDC for EBR in AL and GR for model development 
* Fully functional model bulding
* Improved method for model creation
* Bugfixes


**earlier versions: v1.0.x, v1.1.x and 1.2.x**:
* Earlier versions for finding and evaluation of patterns and sequences (v1.0.x)
* Prototypes for model building functionalities (v1.1.x)
* Prototypes for scoring functionalities (v1.2.x) 

